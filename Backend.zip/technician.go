package models

import "time"

type Category struct {
	ID          string  `json:"id"`
	Name        string  `json:"name"`
	Description string  `json:"description,omitempty"`
	IconURL     string  `json:"icon_url,omitempty"`
	BasePrice   float64 `json:"base_price"`
	IsActive    bool    `json:"is_active"`
	// WarrantyOptions is the admin-configured whitelist of warranty
	// durations (in days) a technician may offer for a job in this
	// category — e.g. [7,15,30,90]. BookingService.Complete rejects any
	// warranty_days value not in this list, so this is the single place
	// that controls what's offerable; a technician can never enter an
	// arbitrary or "unlimited" period.
	WarrantyOptions []int32   `json:"warranty_options"`
	CreatedAt       time.Time `json:"created_at"`
}

// TechnicianPublic is the customer-facing shape returned by the public browse/detail
// endpoints — joins in the technician's name (from users) and service category name,
// and omits internal fields (exact lat/lng, raw ids the UI doesn't need).
type TechnicianPublic struct {
	ID              string  `json:"id"`
	Name            string  `json:"name"`
	CategoryID      string  `json:"category_id"`
	CategoryName    string  `json:"category_name"`
	ExperienceYears int     `json:"experience_years"`
	RatingAvg       float64 `json:"rating_avg"`
	RatingCount     int     `json:"rating_count"`
	IsVerified      bool    `json:"is_verified"`
	IsAvailable     bool    `json:"is_available"`
	// ProfilePhotoURL lets the customer see who they're booking/talking to —
	// same photo the technician sets/changes in their own profile.
	ProfilePhotoURL string `json:"profile_photo_url,omitempty"`
	// CategoryNames is every service this technician offers (technician_categories),
	// e.g. ["Plumbing", "Painting"] — CategoryName above is just the one matched by
	// the current search/filter. Powers the technician detail screen's full skill list.
	CategoryNames []string `json:"category_names,omitempty"`
	// WorkingHours is the technician's self-set weekly schedule (display-only).
	WorkingHours WorkingHours `json:"working_hours,omitempty"`
	CreatedAt    time.Time    `json:"created_at"`
}

// TechnicianNearby is the shape returned by the "find available technicians" endpoint
// used by the customer-facing nearby/tracking screen — joins in name + category name
// (like TechnicianPublic) but also carries live lat/lng and distance from the customer,
// since that's the whole point of this endpoint.
type TechnicianNearby struct {
	ID              string  `json:"id"`
	Name            string  `json:"name"`
	CategoryID      string  `json:"category_id"`
	CategoryName    string  `json:"category_name"`
	ExperienceYears int     `json:"experience_years"`
	RatingAvg       float64 `json:"rating_avg"`
	RatingCount     int     `json:"rating_count"`
	IsAvailable     bool    `json:"is_available"`
	ProfilePhotoURL string  `json:"profile_photo_url,omitempty"`
	// CategoryNames is every service this technician offers — see TechnicianPublic.
	CategoryNames []string `json:"category_names,omitempty"`
	CurrentLat    *float64 `json:"current_lat,omitempty"`
	CurrentLng    *float64 `json:"current_lng,omitempty"`
	// DistanceKm is nil when the caller didn't supply lat/lng (results are then sorted by rating instead).
	DistanceKm *float64 `json:"distance_km,omitempty"`
}

// RepeatCustomer is a customer who has booked a given technician more than once —
// powers the technician's "My Customers" / repeat-customer screen.
type RepeatCustomer struct {
	CustomerID    string    `json:"customer_id"`
	Name          string    `json:"name"`
	Phone         string    `json:"phone"`
	TotalBookings int       `json:"total_bookings"`
	LastBookingAt time.Time `json:"last_booking_at"`
	// ActiveBookingID is set only when this customer currently has a booking
	// with this technician in one of the "call/chat allowed" statuses (see
	// BookingService.InitiateCall) — nil the rest of the time, since most
	// repeat customers only appear here because their PAST job is already
	// completed. The frontend uses this to enable/disable the in-app
	// Call/Chat buttons instead of falling back to the phone dialer.
	ActiveBookingID *string `json:"active_booking_id"`
}

// RepeatTechnician is the customer-side mirror of RepeatCustomer — technicians a
// given customer has booked more than once, powering the customer's "My
// Technicians" (repeat technicians) screen.
type RepeatTechnician struct {
	TechnicianID    string    `json:"technician_id"`
	Name            string    `json:"name"`
	Phone           string    `json:"phone"`
	CategoryName    string    `json:"category_name"`
	ProfilePhotoURL string    `json:"profile_photo_url,omitempty"`
	RatingAvg       float64   `json:"rating_avg"`
	TotalBookings   int       `json:"total_bookings"`
	LastBookingAt   time.Time `json:"last_booking_at"`
}

type Technician struct {
	ID              string `json:"id"`
	UserID          string `json:"user_id"`
	CategoryID      string `json:"category_id"`
	ExperienceYears int    `json:"experience_years"`
	Address         string `json:"address,omitempty"`
	GovernmentIDURL string `json:"government_id_url,omitempty"`
	ProfilePhotoURL string `json:"profile_photo_url,omitempty"`
	// ApprovalStatus is one of "pending", "approved", "rejected" — the source of truth
	// for admin approval. IsVerified is kept in sync for backward-compatible queries.
	ApprovalStatus  string   `json:"approval_status"`
	RejectionReason string   `json:"rejection_reason,omitempty"`
	RatingAvg       float64  `json:"rating_avg"`
	RatingCount     int      `json:"rating_count"`
	IsVerified      bool     `json:"is_verified"`
	IsAvailable     bool     `json:"is_available"`
	CurrentLat      *float64 `json:"current_lat,omitempty"`
	CurrentLng      *float64 `json:"current_lng,omitempty"`
	// WorkingHours is the technician's self-set weekly schedule (display-only).
	WorkingHours WorkingHours `json:"working_hours,omitempty"`
	// CategoryIDs is every category this technician serves (technician_categories) —
	// CategoryID above is just CategoryIDs[0], the "primary" one, kept for anywhere
	// still expecting a single category. Populated by TechnicianService for Me/GetByID;
	// not a DB column on this table.
	CategoryIDs []string  `json:"category_ids,omitempty"`
	CreatedAt   time.Time `json:"created_at"`
	UpdatedAt   time.Time `json:"updated_at"`
}

// TechnicianWithUser adds the user's own name/phone and the category's display
// name — used by the admin panel's Technician Approval queue, which needs to show
// who's asking (and their KYC documents) without a separate lookup per row.
type TechnicianWithUser struct {
	ID              string    `json:"id"`
	UserID          string    `json:"user_id"`
	Name            string    `json:"name"`
	Phone           string    `json:"phone"`
	CategoryID      string    `json:"category_id"`
	CategoryName    string    `json:"category_name"`
	ExperienceYears int       `json:"experience_years"`
	Address         string    `json:"address,omitempty"`
	GovernmentIDURL string    `json:"government_id_url,omitempty"`
	ProfilePhotoURL string    `json:"profile_photo_url,omitempty"`
	ApprovalStatus  string    `json:"approval_status"`
	RejectionReason string    `json:"rejection_reason,omitempty"`
	RatingAvg       float64   `json:"rating_avg"`
	RatingCount     int       `json:"rating_count"`
	IsVerified      bool      `json:"is_verified"`
	IsAvailable     bool      `json:"is_available"`
	CreatedAt       time.Time `json:"created_at"`
}
