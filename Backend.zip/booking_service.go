package service

import (
	"context"
	"errors"
	"fmt"

	"homefix-backend/internal/models"
	"homefix-backend/internal/repository"
	"homefix-backend/internal/utils"
)

type BookingService struct {
	bookingRepo *repository.BookingRepository
	catRepo     *repository.CategoryRepository
	techRepo    *repository.TechnicianRepository
	paymentRepo *repository.PaymentRepository
	fcm         *FirebaseService
}

func NewBookingService(bookingRepo *repository.BookingRepository, catRepo *repository.CategoryRepository, techRepo *repository.TechnicianRepository, paymentRepo *repository.PaymentRepository, fcm *FirebaseService) *BookingService {
	return &BookingService{bookingRepo: bookingRepo, catRepo: catRepo, techRepo: techRepo, paymentRepo: paymentRepo, fcm: fcm}
}

// Create makes a new booking. If preferredTechnicianID is non-empty (customer
// picked a specific technician via "Book Now" on their profile), the booking
// is created and then immediately assigned to that technician (status jumps
// straight to "accepted") instead of sitting as "requested" waiting for any
// technician to accept it.
func (s *BookingService) Create(ctx context.Context, b *models.Booking, preferredTechnicianID string) (*models.Booking, error) {
	cat, err := s.catRepo.GetByID(ctx, b.CategoryID)
	if err != nil {
		return nil, err
	}
	if cat == nil {
		return nil, errors.New("category not found")
	}
	if b.EstimatedPrice == nil {
		price := cat.BasePrice
		b.EstimatedPrice = &price
	}

	created, err := s.bookingRepo.Create(ctx, b)
	if err != nil {
		return nil, err
	}

	if preferredTechnicianID != "" {
		tech, err := s.techRepo.GetByID(ctx, preferredTechnicianID)
		if err != nil {
			return nil, err
		}
		if tech == nil {
			return nil, errors.New("selected technician not found")
		}
		if err := s.bookingRepo.AssignTechnician(ctx, created.ID, preferredTechnicianID); err != nil {
			return nil, err
		}
		created.TechnicianID = &preferredTechnicianID
		created.Status = models.BookingAccepted

		if s.fcm != nil {
			_ = s.fcm.SendToUser(ctx, tech.UserID, "New booking request",
				"You have a new booking request.",
				map[string]string{"booking_id": created.ID, "type": "booking_assigned"})
		}
	}

	return created, nil
}

func (s *BookingService) Get(ctx context.Context, id string) (*models.Booking, error) {
	return s.bookingRepo.GetByID(ctx, id)
}

// GetDetail returns a booking with the joined customer/technician/address info.
func (s *BookingService) GetDetail(ctx context.Context, id string) (*models.BookingDetail, error) {
	return s.bookingRepo.GetDetailByID(ctx, id)
}

func (s *BookingService) ListForCustomer(ctx context.Context, customerID string) ([]models.Booking, error) {
	return s.bookingRepo.ListByCustomer(ctx, customerID)
}

func (s *BookingService) ListForTechnician(ctx context.Context, technicianID string) ([]models.Booking, error) {
	return s.bookingRepo.ListByTechnician(ctx, technicianID)
}

// ListForCustomerDetailed powers the customer's "My Bookings" screen — each booking
// carries the assigned technician's name/phone/rating once one is assigned.
func (s *BookingService) ListForCustomerDetailed(ctx context.Context, customerID string) ([]models.BookingDetail, error) {
	return s.bookingRepo.ListByCustomerDetailed(ctx, customerID)
}

// ListForTechnicianDetailed powers the technician's "My Jobs" screen — each booking
// carries the customer's name/phone and the job address.
func (s *BookingService) ListForTechnicianDetailed(ctx context.Context, technicianID string) ([]models.BookingDetail, error) {
	return s.bookingRepo.ListByTechnicianDetailed(ctx, technicianID)
}

// Accept assigns a technician to a booking and notifies the customer via real FCM push.
func (s *BookingService) Accept(ctx context.Context, bookingID, technicianID string) error {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return err
	}
	if b == nil {
		return errors.New("booking not found")
	}
	if b.Status != models.BookingRequested {
		return errors.New("booking is not in a requested state")
	}

	if err := s.bookingRepo.AssignTechnician(ctx, bookingID, technicianID); err != nil {
		return err
	}

	if s.fcm != nil {
		_ = s.fcm.SendToUser(ctx, b.CustomerID, "Technician assigned",
			"A technician has accepted your booking and is on the way.",
			map[string]string{"booking_id": bookingID, "type": "booking_accepted"})
	}
	return nil
}

// Arrived marks the technician as having reached the customer's location and
// generates a fresh 6-digit OTP (Uber-style). The code is stored on the
// booking and only ever surfaced to the CUSTOMER (BookingHandler.Get strips
// it before returning a booking to anyone else) — the customer reads it out
// to the technician, who enters it back via VerifyArrivalOTP to actually
// start the job.
func (s *BookingService) Arrived(ctx context.Context, bookingID, technicianID string) error {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return err
	}
	if b == nil {
		return errors.New("booking not found")
	}
	if b.TechnicianID == nil || *b.TechnicianID != technicianID {
		return errors.New("you are not the technician assigned to this booking")
	}

	otp, err := utils.GenerateOTP()
	if err != nil {
		return err
	}
	if err := s.bookingRepo.SetArrivalOTP(ctx, bookingID, otp); err != nil {
		return err
	}

	if s.fcm != nil {
		_ = s.fcm.SendToUser(ctx, b.CustomerID, "Technician has arrived",
			"Your technician is at your location. Share your OTP with them to start the service.",
			map[string]string{"booking_id": bookingID, "type": "booking_arrived"})
	}
	return nil
}

// VerifyArrivalOTP checks the code the technician typed in (read out to them
// by the customer) against the one generated in Arrived. Only on a match does
// the booking move to in_progress — this is what stops a technician from
// starting (and later billing for) a job without genuinely being on-site.
func (s *BookingService) VerifyArrivalOTP(ctx context.Context, bookingID, technicianID, code string) error {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return err
	}
	if b == nil {
		return errors.New("booking not found")
	}
	if b.TechnicianID == nil || *b.TechnicianID != technicianID {
		return errors.New("you are not the technician assigned to this booking")
	}
	if b.Status != models.BookingArrived {
		return errors.New("booking is not awaiting OTP verification")
	}

	stored, err := s.bookingRepo.GetOTP(ctx, bookingID)
	if err != nil {
		return err
	}
	if stored == "" || stored != code {
		return errors.New("incorrect OTP")
	}

	if err := s.bookingRepo.VerifyOTP(ctx, bookingID); err != nil {
		return err
	}

	if s.fcm != nil {
		_ = s.fcm.SendToUser(ctx, b.CustomerID, "Service started",
			"OTP verified. Your technician has started the job.",
			map[string]string{"booking_id": bookingID, "type": "booking_in_progress"})
	}
	return nil
}

// --- Physical Inspection -> Estimate -> Approval ---

// SubmitEstimate is called once the technician has physically inspected the
// job on-site and worked out a labour+parts cost breakdown. Only callable
// while the booking is in_progress (i.e. after arrival/OTP, before
// completion) and only by the technician assigned to it. Moves the booking
// to awaiting_estimate_approval and notifies the customer; Complete() can't
// be reached again until the customer approves (see RespondToEstimate).
func (s *BookingService) SubmitEstimate(ctx context.Context, bookingID, technicianID string, items []models.BookingEstimateItem, note string) (*models.BookingEstimate, error) {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return nil, err
	}
	if b == nil {
		return nil, errors.New("booking not found")
	}
	if b.TechnicianID == nil || *b.TechnicianID != technicianID {
		return nil, errors.New("you are not the technician assigned to this booking")
	}
	if b.Status != models.BookingInProgress {
		return nil, errors.New("an estimate can only be submitted while the job is in progress")
	}
	if len(items) == 0 {
		return nil, errors.New("estimate must include at least one line item")
	}

	var labourTotal, partsTotal float64
	cleanItems := make([]models.BookingEstimateItem, 0, len(items))
	for _, it := range items {
		if it.Name == "" {
			return nil, errors.New("each estimate item needs a name")
		}
		if it.ItemType != models.EstimateItemLabour && it.ItemType != models.EstimateItemPart {
			return nil, errors.New("item_type must be 'labour' or 'part'")
		}
		if it.Quantity <= 0 {
			it.Quantity = 1
		}
		if it.UnitPrice < 0 {
			return nil, errors.New("unit_price cannot be negative")
		}
		// Amount is always derived server-side, never trusted from the client.
		it.Amount = it.Quantity * it.UnitPrice
		if it.ItemType == models.EstimateItemLabour {
			labourTotal += it.Amount
		} else {
			partsTotal += it.Amount
		}
		cleanItems = append(cleanItems, it)
	}

	e := &models.BookingEstimate{
		BookingID:    bookingID,
		TechnicianID: technicianID,
		LabourAmount: labourTotal,
		PartsAmount:  partsTotal,
		TotalAmount:  labourTotal + partsTotal,
		Items:        cleanItems,
	}
	if note != "" {
		e.Note = &note
	}

	created, err := s.bookingRepo.CreateEstimate(ctx, e)
	if err != nil {
		return nil, err
	}

	if err := s.bookingRepo.UpdateStatus(ctx, bookingID, models.BookingAwaitingEstimateApproval, "Technician submitted an estimate for approval"); err != nil {
		return nil, err
	}

	if s.fcm != nil {
		_ = s.fcm.SendToUser(ctx, b.CustomerID, "Estimate ready for your approval",
			fmt.Sprintf("Your technician has inspected the job and quoted \u20b9%.2f. Tap to review.", created.TotalAmount),
			map[string]string{"booking_id": bookingID, "type": "estimate_submitted", "estimate_id": created.ID})
	}

	return created, nil
}

// GetLatestEstimate returns the most recent estimate submitted for a booking
// (whatever its status), with items — powers both the customer's approval
// screen and the technician's "estimate sent" view.
func (s *BookingService) GetLatestEstimate(ctx context.Context, bookingID string) (*models.BookingEstimate, error) {
	return s.bookingRepo.GetLatestEstimate(ctx, bookingID)
}

// ListEstimates returns every estimate ever submitted for a booking — the
// full negotiation history across declines/resubmissions.
func (s *BookingService) ListEstimates(ctx context.Context, bookingID string) ([]models.BookingEstimate, error) {
	return s.bookingRepo.ListEstimatesForBooking(ctx, bookingID)
}

// RespondToEstimate is how the customer approves or declines a pending
// estimate. Approving moves the booking back to in_progress so the
// technician can finish (and eventually complete/invoice) the job, and
// updates estimated_price to the agreed total. Declining also returns the
// booking to in_progress so the technician can revise and resubmit a new
// estimate — it does NOT cancel the booking.
func (s *BookingService) RespondToEstimate(ctx context.Context, bookingID, estimateID, customerID, action, note string) error {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return err
	}
	if b == nil {
		return errors.New("booking not found")
	}
	if b.CustomerID != customerID {
		return errors.New("you are not the customer for this booking")
	}
	if b.Status != models.BookingAwaitingEstimateApproval {
		return errors.New("this booking has no estimate awaiting approval")
	}

	est, err := s.bookingRepo.GetEstimateByID(ctx, estimateID)
	if err != nil {
		return err
	}
	if est == nil || est.BookingID != bookingID {
		return errors.New("estimate not found for this booking")
	}
	if est.Status != models.EstimateStatusPending {
		return errors.New("this estimate has already been responded to")
	}

	var technicianUserID string
	if b.TechnicianID != nil {
		if tech, err := s.techRepo.GetByID(ctx, *b.TechnicianID); err == nil && tech != nil {
			technicianUserID = tech.UserID
		}
	}

	switch action {
	case "approve":
		if err := s.bookingRepo.UpdateEstimateStatus(ctx, estimateID, models.EstimateStatusApproved, nil); err != nil {
			return err
		}
		if err := s.bookingRepo.SetEstimatedPrice(ctx, bookingID, est.TotalAmount); err != nil {
			return err
		}
		if err := s.bookingRepo.UpdateStatus(ctx, bookingID, models.BookingInProgress, "Customer approved the estimate"); err != nil {
			return err
		}
		if s.fcm != nil && technicianUserID != "" {
			_ = s.fcm.SendToUser(ctx, technicianUserID, "Estimate approved",
				fmt.Sprintf("The customer approved your \u20b9%.2f estimate. You can proceed with the job.", est.TotalAmount),
				map[string]string{"booking_id": bookingID, "type": "estimate_approved", "estimate_id": estimateID})
		}
	case "decline":
		var noteRef *string
		if note != "" {
			noteRef = &note
		}
		if err := s.bookingRepo.UpdateEstimateStatus(ctx, estimateID, models.EstimateStatusDeclined, noteRef); err != nil {
			return err
		}
		if err := s.bookingRepo.UpdateStatus(ctx, bookingID, models.BookingInProgress, "Customer declined the estimate"); err != nil {
			return err
		}
		if s.fcm != nil && technicianUserID != "" {
			msg := "The customer declined your estimate."
			if note != "" {
				msg += " Reason: " + note
			}
			_ = s.fcm.SendToUser(ctx, technicianUserID, "Estimate declined", msg,
				map[string]string{"booking_id": bookingID, "type": "estimate_declined", "estimate_id": estimateID})
		}
	default:
		return errors.New("action must be 'approve' or 'decline'")
	}

	return nil
}

func (s *BookingService) UpdateStatus(ctx context.Context, bookingID, status, note string) error {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return err
	}
	if b == nil {
		return errors.New("booking not found")
	}
	if err := s.bookingRepo.UpdateStatus(ctx, bookingID, status, note); err != nil {
		return err
	}
	if s.fcm != nil {
		_ = s.fcm.SendToUser(ctx, b.CustomerID, "Booking update",
			"Your booking status changed to "+status, map[string]string{"booking_id": bookingID, "type": "booking_status"})
	}
	return nil
}

// Complete records the technician's final_price — this IS the invoice, since
// it's the only number the app ever asks the customer to pay (see
// UpiService.CreateOrder, which validates the payment amount against it). The
// FCM push here is the only signal the customer gets that a bill is ready;
// without it they'd only find out by happening to reopen the booking.
func (s *BookingService) Complete(ctx context.Context, bookingID string, finalPrice float64) error {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return err
	}
	if b == nil {
		return errors.New("booking not found")
	}
	if b.Status == models.BookingAwaitingEstimateApproval {
		return errors.New("cannot complete the job while an estimate is awaiting customer approval")
	}

	if err := s.bookingRepo.SetFinalPrice(ctx, bookingID, finalPrice); err != nil {
		return err
	}
	if err := s.bookingRepo.UpdateStatus(ctx, bookingID, models.BookingCompleted, "Job completed"); err != nil {
		return err
	}

	if s.fcm != nil {
		_ = s.fcm.SendToUser(ctx, b.CustomerID, "Invoice ready",
			fmt.Sprintf("Your technician has completed the job. Amount due: \u20b9%.2f. Tap to pay.", finalPrice),
			map[string]string{"booking_id": bookingID, "type": "invoice_ready", "final_price": fmt.Sprintf("%.2f", finalPrice)})
	}
	return nil
}

func (s *BookingService) Cancel(ctx context.Context, bookingID, reason string) error {
	return s.bookingRepo.UpdateStatus(ctx, bookingID, models.BookingCancelled, reason)
}

func (s *BookingService) History(ctx context.Context, bookingID string) ([]models.BookingStatusHistory, error) {
	return s.bookingRepo.History(ctx, bookingID)
}

// RepeatCustomers powers the technician's "My Customers" screen — customers who
// have booked this technician more than once.
func (s *BookingService) RepeatCustomers(ctx context.Context, technicianID string) ([]models.RepeatCustomer, error) {
	return s.bookingRepo.ListRepeatCustomersByTechnician(ctx, technicianID)
}

// RepeatTechnicians is the customer-side mirror of RepeatCustomers — powers the
// customer's "My Technicians" screen with technicians they've booked more than
// once.
func (s *BookingService) RepeatTechnicians(ctx context.Context, customerID string) ([]models.RepeatTechnician, error) {
	return s.bookingRepo.ListRepeatTechniciansByCustomer(ctx, customerID)
}

// ServiceHistory returns every past booking a specific customer has made with a
// specific technician, each with its payment/pricing-tier info attached — reached
// from the technician's repeat-customers list by tapping a customer.
func (s *BookingService) ServiceHistory(ctx context.Context, technicianID, customerID string) ([]models.ServiceHistoryEntry, error) {
	bookings, err := s.bookingRepo.ListByCustomerAndTechnicianDetailed(ctx, customerID, technicianID)
	if err != nil {
		return nil, err
	}

	out := make([]models.ServiceHistoryEntry, 0, len(bookings))
	for _, b := range bookings {
		entry := models.ServiceHistoryEntry{BookingDetail: b}
		if s.paymentRepo != nil {
			if p, err := s.paymentRepo.GetByBookingID(ctx, b.ID); err == nil && p != nil {
				entry.Payment = &models.ServiceHistoryPayment{
					Amount:                p.Amount,
					Status:                p.Status,
					IsRepeatCustomer:      p.IsRepeatCustomer,
					RepeatDiscountPercent: p.RepeatDiscountPercent,
					RepeatDiscountAmount:  p.RepeatDiscountAmount,
				}
			}
		}
		out = append(out, entry)
	}
	return out, nil
}

// --- Booking chat ---
//
// Only the booking's customer, or the technician actually assigned to it,
// may read/send messages. userRole comes from the JWT claims set by the auth
// middleware; senderRole recorded on each message is derived from that, not
// trusted from the client body.

func (s *BookingService) SendMessage(ctx context.Context, bookingID, userID, userRole, content string) (*models.BookingMessage, error) {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return nil, err
	}
	if b == nil {
		return nil, errors.New("booking not found")
	}

	senderRole, err := s.resolveBookingParticipantRole(ctx, b, userID, userRole)
	if err != nil {
		return nil, err
	}

	msg := &models.BookingMessage{BookingID: bookingID, SenderID: userID, SenderRole: senderRole, Content: content}
	created, err := s.bookingRepo.CreateMessage(ctx, msg)
	if err != nil {
		return nil, err
	}

	if s.fcm != nil {
		recipientID := b.CustomerID
		if senderRole == "customer" && b.TechnicianID != nil {
			if tech, err := s.techRepo.GetByID(ctx, *b.TechnicianID); err == nil && tech != nil {
				recipientID = tech.UserID
			}
		}
		if recipientID != userID {
			_ = s.fcm.SendToUser(ctx, recipientID, "New message",
				content, map[string]string{"booking_id": bookingID, "type": "booking_message"})
		}
	}

	return created, nil
}

func (s *BookingService) ListMessages(ctx context.Context, bookingID, userID, userRole string) ([]models.BookingMessage, error) {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return nil, err
	}
	if b == nil {
		return nil, errors.New("booking not found")
	}
	if _, err := s.resolveBookingParticipantRole(ctx, b, userID, userRole); err != nil {
		return nil, err
	}
	return s.bookingRepo.ListMessages(ctx, bookingID)
}

// --- Before/After job proof photos ---

// AddJobPhoto lets the technician assigned to a booking attach a "before" or
// "after" proof photo. Restricted to the assigned technician (not just any
// technician) and to jobs that have actually started — a "before" photo
// makes sense once accepted/on the way/arrived, "after" only once work is
// under way, so we simply require the booking be past "requested".
func (s *BookingService) AddJobPhoto(ctx context.Context, bookingID, technicianUserID, photoType, imageURL, caption string) (*models.BookingJobPhoto, error) {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return nil, err
	}
	if b == nil {
		return nil, errors.New("booking not found")
	}
	if b.TechnicianID == nil {
		return nil, errors.New("no technician assigned to this booking yet")
	}
	tech, err := s.techRepo.GetByID(ctx, *b.TechnicianID)
	if err != nil {
		return nil, err
	}
	if tech == nil || tech.UserID != technicianUserID {
		return nil, errors.New("you are not the technician assigned to this booking")
	}
	if b.Status == models.BookingRequested {
		return nil, errors.New("cannot attach job photos before the booking is accepted")
	}
	if photoType != models.JobPhotoBefore && photoType != models.JobPhotoAfter {
		return nil, errors.New("photo_type must be \"before\" or \"after\"")
	}
	if imageURL == "" {
		return nil, errors.New("image_url is required")
	}

	var captionPtr *string
	if caption != "" {
		captionPtr = &caption
	}

	photo := &models.BookingJobPhoto{
		BookingID:    bookingID,
		TechnicianID: *b.TechnicianID,
		PhotoType:    photoType,
		ImageURL:     imageURL,
		Caption:      captionPtr,
	}
	return s.bookingRepo.AddJobPhoto(ctx, photo)
}

// ListJobPhotos returns every before/after photo for a booking, oldest
// first. Any participant (customer or the assigned technician) may view.
func (s *BookingService) ListJobPhotos(ctx context.Context, bookingID, userID, userRole string) ([]models.BookingJobPhoto, error) {
	b, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return nil, err
	}
	if b == nil {
		return nil, errors.New("booking not found")
	}
	if _, err := s.resolveBookingParticipantRole(ctx, b, userID, userRole); err != nil {
		return nil, err
	}
	return s.bookingRepo.ListJobPhotos(ctx, bookingID)
}

// resolveBookingParticipantRole confirms userID is actually a party to
// booking b (its customer, or its assigned technician) and returns which
// side they're on ("customer" | "technician"). Admins may also read/send for
// support purposes, recorded as "technician" side.
func (s *BookingService) resolveBookingParticipantRole(ctx context.Context, b *models.Booking, userID, userRole string) (string, error) {
	if userID == b.CustomerID {
		return "customer", nil
	}
	if userRole == "admin" {
		return "technician", nil
	}
	if b.TechnicianID != nil {
		tech, err := s.techRepo.GetByID(ctx, *b.TechnicianID)
		if err != nil {
			return "", err
		}
		if tech != nil && tech.UserID == userID {
			return "technician", nil
		}
	}
	return "", errors.New("you are not a participant in this booking")
}