package handler

import (
	"net/http"
	"time"

	"github.com/gin-gonic/gin"

	"homefix-backend/internal/models"
	"homefix-backend/internal/service"
	"homefix-backend/internal/utils"
)

type BookingHandler struct {
	bookingService *service.BookingService
}

func NewBookingHandler(bookingService *service.BookingService) *BookingHandler {
	return &BookingHandler{bookingService: bookingService}
}

type createBookingBody struct {
	CategoryID         string     `json:"category_id" binding:"required"`
	AddressID          string     `json:"address_id" binding:"required"`
	TechnicianID       *string    `json:"technician_id"`
	ProblemDescription string     `json:"problem_description"`
	Notes              *string    `json:"notes"`
	Images             []string   `json:"images"`
	ScheduledAt        *time.Time `json:"scheduled_at"`
}

func (h *BookingHandler) Create(c *gin.Context) {
	userID := c.GetString("user_id")
	var body createBookingBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	b := &models.Booking{
		CustomerID:         userID,
		CategoryID:         body.CategoryID,
		AddressID:          body.AddressID,
		ProblemDescription: body.ProblemDescription,
		Notes:              body.Notes,
		Images:             body.Images,
		ScheduledAt:        body.ScheduledAt,
	}
	var preferredTechnicianID string
	if body.TechnicianID != nil {
		preferredTechnicianID = *body.TechnicianID
	}
	created, err := h.bookingService.Create(c.Request.Context(), b, preferredTechnicianID)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusCreated, created)
}

func (h *BookingHandler) Get(c *gin.Context) {
	id := c.Param("id")
	b, err := h.bookingService.GetDetail(c.Request.Context(), id)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	if b == nil {
		utils.Error(c, http.StatusNotFound, "booking not found")
		return
	}
	// The arrival OTP is for the customer to read out loud — never send it to
	// the technician or anyone else viewing the booking.
	if c.GetString("user_id") != b.CustomerID {
		b.OtpCode = nil
	}
	utils.Success(c, http.StatusOK, b)
}

func (h *BookingHandler) MyBookings(c *gin.Context) {
	userID := c.GetString("user_id")
	list, err := h.bookingService.ListForCustomerDetailed(c.Request.Context(), userID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, list)
}

func (h *BookingHandler) TechnicianBookings(c *gin.Context) {
	technicianID := c.Param("id")
	list, err := h.bookingService.ListForTechnicianDetailed(c.Request.Context(), technicianID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	// Technicians must ask the customer for the OTP out loud, never read it
	// off their own booking list.
	for i := range list {
		list[i].OtpCode = nil
	}
	utils.Success(c, http.StatusOK, list)
}

// RepeatCustomers powers the technician's "My Customers" screen.
func (h *BookingHandler) RepeatCustomers(c *gin.Context) {
	technicianID := c.Param("id")
	list, err := h.bookingService.RepeatCustomers(c.Request.Context(), technicianID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	if list == nil {
		list = []models.RepeatCustomer{}
	}
	utils.Success(c, http.StatusOK, list)
}

// RepeatTechnicians is the customer-side mirror of RepeatCustomers — powers the
// customer's "My Technicians" screen.
func (h *BookingHandler) RepeatTechnicians(c *gin.Context) {
	customerID := c.GetString("user_id")
	list, err := h.bookingService.RepeatTechnicians(c.Request.Context(), customerID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	if list == nil {
		list = []models.RepeatTechnician{}
	}
	utils.Success(c, http.StatusOK, list)
}

// MyServiceHistoryWithTechnician is the customer-side mirror of ServiceHistory —
// every past booking the logged-in customer has made with a specific technician
// (date, work done/category, status, payment amount). Reached by tapping a
// technician on the customer's "My Technicians" screen.
func (h *BookingHandler) MyServiceHistoryWithTechnician(c *gin.Context) {
	customerID := c.GetString("user_id")
	technicianID := c.Param("technicianId")
	list, err := h.bookingService.ServiceHistory(c.Request.Context(), technicianID, customerID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	if list == nil {
		list = []models.ServiceHistoryEntry{}
	}
	utils.Success(c, http.StatusOK, list)
}

// ServiceHistory returns a specific customer's past bookings with this
// technician, each with pricing/tier info — reached by tapping a customer on
// the technician's "My Customers" (repeat customers) screen.
func (h *BookingHandler) ServiceHistory(c *gin.Context) {
	technicianID := c.Param("id")
	customerID := c.Param("customerId")
	list, err := h.bookingService.ServiceHistory(c.Request.Context(), technicianID, customerID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	if list == nil {
		list = []models.ServiceHistoryEntry{}
	}
	utils.Success(c, http.StatusOK, list)
}

type acceptBody struct {
	TechnicianID string `json:"technician_id" binding:"required"`
}

func (h *BookingHandler) Accept(c *gin.Context) {
	bookingID := c.Param("id")
	var body acceptBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := h.bookingService.Accept(c.Request.Context(), bookingID, body.TechnicianID); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, gin.H{"message": "booking accepted"})
}

type arrivedBody struct {
	TechnicianID string `json:"technician_id" binding:"required"`
}

// Arrived — POST /bookings/:id/arrived. Technician taps "I've arrived"; backend
// generates a fresh OTP and sends it (via FCM data payload) to the customer only.
func (h *BookingHandler) Arrived(c *gin.Context) {
	bookingID := c.Param("id")
	var body arrivedBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := h.bookingService.Arrived(c.Request.Context(), bookingID, body.TechnicianID); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, gin.H{"message": "marked as arrived, OTP sent to customer"})
}

type verifyOtpBody struct {
	TechnicianID string `json:"technician_id" binding:"required"`
	Otp          string `json:"otp" binding:"required"`
}

// VerifyOtp — POST /bookings/:id/verify-otp. Technician enters the code the
// customer read out to them; only on a match does the job move to in_progress.
func (h *BookingHandler) VerifyOtp(c *gin.Context) {
	bookingID := c.Param("id")
	var body verifyOtpBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := h.bookingService.VerifyArrivalOTP(c.Request.Context(), bookingID, body.TechnicianID, body.Otp); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, gin.H{"message": "OTP verified, service started"})
}

type statusBody struct {
	Status string `json:"status" binding:"required"`
	Note   string `json:"note"`
}

func (h *BookingHandler) UpdateStatus(c *gin.Context) {
	bookingID := c.Param("id")
	var body statusBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := h.bookingService.UpdateStatus(c.Request.Context(), bookingID, body.Status, body.Note); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, gin.H{"message": "status updated"})
}

// --- Physical Inspection -> Estimate -> Approval ---

type estimateItemBody struct {
	ItemType  string  `json:"item_type" binding:"required"` // "labour" | "part"
	Name      string  `json:"name" binding:"required"`
	Quantity  float64 `json:"quantity"`
	UnitPrice float64 `json:"unit_price" binding:"required"`
}

type submitEstimateBody struct {
	TechnicianID string             `json:"technician_id" binding:"required"`
	Items        []estimateItemBody `json:"items" binding:"required,min=1"`
	Note         string             `json:"note"`
}

// SubmitEstimate — POST /bookings/:id/estimate. Technician submits a
// labour+parts breakdown after physically inspecting the job; moves the
// booking to awaiting_estimate_approval.
func (h *BookingHandler) SubmitEstimate(c *gin.Context) {
	bookingID := c.Param("id")
	var body submitEstimateBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}

	items := make([]models.BookingEstimateItem, 0, len(body.Items))
	for _, it := range body.Items {
		items = append(items, models.BookingEstimateItem{
			ItemType:  it.ItemType,
			Name:      it.Name,
			Quantity:  it.Quantity,
			UnitPrice: it.UnitPrice,
		})
	}

	estimate, err := h.bookingService.SubmitEstimate(c.Request.Context(), bookingID, body.TechnicianID, items, body.Note)
	if err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusCreated, estimate)
}

// GetLatestEstimate — GET /bookings/:id/estimate. Returns the most recently
// submitted estimate (whatever its status) with its line items.
func (h *BookingHandler) GetLatestEstimate(c *gin.Context) {
	bookingID := c.Param("id")
	estimate, err := h.bookingService.GetLatestEstimate(c.Request.Context(), bookingID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	if estimate == nil {
		utils.Error(c, http.StatusNotFound, "no estimate found for this booking")
		return
	}
	utils.Success(c, http.StatusOK, estimate)
}

// ListEstimates — GET /bookings/:id/estimates. Full negotiation history —
// every estimate ever submitted for the booking, oldest first.
func (h *BookingHandler) ListEstimates(c *gin.Context) {
	bookingID := c.Param("id")
	list, err := h.bookingService.ListEstimates(c.Request.Context(), bookingID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	if list == nil {
		list = []models.BookingEstimate{}
	}
	utils.Success(c, http.StatusOK, list)
}

type respondEstimateBody struct {
	Action string `json:"action" binding:"required"` // "approve" | "decline"
	Note   string `json:"note"`
}

// RespondEstimate — POST /bookings/:id/estimate/:estimateId/respond. Customer
// approves or declines a pending estimate; either way the booking returns to
// in_progress (approve = proceed to finish the job, decline = technician
// revises and resubmits).
func (h *BookingHandler) RespondEstimate(c *gin.Context) {
	bookingID := c.Param("id")
	estimateID := c.Param("estimateId")
	customerID := c.GetString("user_id")

	var body respondEstimateBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}

	if err := h.bookingService.RespondToEstimate(c.Request.Context(), bookingID, estimateID, customerID, body.Action, body.Note); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, gin.H{"message": "estimate response recorded"})
}

type completeBody struct {
	FinalPrice float64 `json:"final_price" binding:"required"`
}

func (h *BookingHandler) Complete(c *gin.Context) {
	bookingID := c.Param("id")
	var body completeBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	if err := h.bookingService.Complete(c.Request.Context(), bookingID, body.FinalPrice); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, gin.H{"message": "booking completed"})
}

type cancelBody struct {
	Reason string `json:"reason"`
}

func (h *BookingHandler) Cancel(c *gin.Context) {
	bookingID := c.Param("id")
	var body cancelBody
	_ = c.ShouldBindJSON(&body)
	if err := h.bookingService.Cancel(c.Request.Context(), bookingID, body.Reason); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, gin.H{"message": "booking cancelled"})
}

func (h *BookingHandler) History(c *gin.Context) {
	bookingID := c.Param("id")
	hist, err := h.bookingService.History(c.Request.Context(), bookingID)
	if err != nil {
		utils.Error(c, http.StatusInternalServerError, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, hist)
}

type bookingSendMessageBody struct {
	Content string `json:"content" binding:"required"`
}

// SendMessage — POST /bookings/:id/messages. Either the booking's customer
// or its assigned technician can post; role/participation is verified
// server-side in BookingService, not trusted from the client.
func (h *BookingHandler) SendMessage(c *gin.Context) {
	bookingID := c.Param("id")
	userID := c.GetString("user_id")
	userRole := c.GetString("role")

	var body bookingSendMessageBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}

	msg, err := h.bookingService.SendMessage(c.Request.Context(), bookingID, userID, userRole, body.Content)
	if err != nil {
		utils.Error(c, http.StatusForbidden, err.Error())
		return
	}
	utils.Success(c, http.StatusCreated, msg)
}

// ListMessages — GET /bookings/:id/messages
func (h *BookingHandler) ListMessages(c *gin.Context) {
	bookingID := c.Param("id")
	userID := c.GetString("user_id")
	userRole := c.GetString("role")

	msgs, err := h.bookingService.ListMessages(c.Request.Context(), bookingID, userID, userRole)
	if err != nil {
		utils.Error(c, http.StatusForbidden, err.Error())
		return
	}
	utils.Success(c, http.StatusOK, msgs)
}

// --- Before/After job proof photos ---

type addJobPhotoBody struct {
	PhotoType string `json:"photo_type" binding:"required"` // "before" | "after"
	ImageURL  string `json:"image_url" binding:"required"`  // from POST /uploads
	Caption   string `json:"caption"`
}

// AddJobPhoto — POST /bookings/:id/photos. Technician attaches a before/after
// proof photo (client uploads via POST /uploads first, then posts the
// returned URL here).
func (h *BookingHandler) AddJobPhoto(c *gin.Context) {
	bookingID := c.Param("id")
	userID := c.GetString("user_id")

	var body addJobPhotoBody
	if err := c.ShouldBindJSON(&body); err != nil {
		utils.Error(c, http.StatusBadRequest, err.Error())
		return
	}

	photo, err := h.bookingService.AddJobPhoto(c.Request.Context(), bookingID, userID, body.PhotoType, body.ImageURL, body.Caption)
	if err != nil {
		utils.Error(c, http.StatusForbidden, err.Error())
		return
	}
	utils.Success(c, http.StatusCreated, photo)
}

// ListJobPhotos — GET /bookings/:id/photos
func (h *BookingHandler) ListJobPhotos(c *gin.Context) {
	bookingID := c.Param("id")
	userID := c.GetString("user_id")
	userRole := c.GetString("role")

	photos, err := h.bookingService.ListJobPhotos(c.Request.Context(), bookingID, userID, userRole)
	if err != nil {
		utils.Error(c, http.StatusForbidden, err.Error())
		return
	}
	if photos == nil {
		photos = []models.BookingJobPhoto{}
	}
	utils.Success(c, http.StatusOK, photos)
}