package models

import "time"

const (
	BookingRequested                = "requested"
	BookingAccepted                 = "accepted"
	BookingOnTheWay                 = "on_the_way" // technician has started travelling to the customer
	BookingArrived                  = "arrived"    // technician reached the location; waiting on OTP from customer
	BookingInProgress               = "in_progress"
	BookingAwaitingEstimateApproval = "awaiting_estimate_approval" // technician has inspected on-site and submitted an estimate; waiting on the customer to approve/decline
	BookingCompleted                = "completed"
	BookingCancelled                = "cancelled"
)

// Estimate item types and statuses — see BookingEstimate below.
const (
	EstimateItemLabour = "labour"
	EstimateItemPart   = "part"

	EstimateStatusPending  = "pending"
	EstimateStatusApproved = "approved"
	EstimateStatusDeclined = "declined"
)

// Job photo types — see BookingJobPhoto below.
const (
	JobPhotoBefore = "before"
	JobPhotoAfter  = "after"
)

type Booking struct {
	ID                 string     `json:"id"`
	CustomerID         string     `json:"customer_id"`
	TechnicianID       *string    `json:"technician_id,omitempty"`
	CategoryID         string     `json:"category_id"`
	AddressID          string     `json:"address_id"`
	Status             string     `json:"status"`
	ServiceCode        string     `json:"service_code,omitempty"` // e.g. "SRV-001042" — a stable, human-readable ID for invoices/receipts, distinct from the internal UUID
	PaymentStatus      string     `json:"payment_status"`         // pending | paid | refunded — set only via verified UpiService.ConfirmPayment
	ProblemDescription string     `json:"problem_description,omitempty"`
	Notes              *string    `json:"notes,omitempty"`
	Images             []string   `json:"images,omitempty"`
	ScheduledAt        *time.Time `json:"scheduled_at,omitempty"`
	EstimatedPrice     *float64   `json:"estimated_price,omitempty"`
	FinalPrice         *float64   `json:"final_price,omitempty"`
	// OtpCode is the arrival OTP the customer reads out to the technician
	// (Uber-style). It's generated when the technician marks themselves
	// "arrived" and is only ever included in the response sent to the
	// booking's customer — BookingHandler strips it before returning a
	// booking to anyone else.
	OtpCode       *string    `json:"otp_code,omitempty"`
	OtpVerifiedAt *time.Time `json:"otp_verified_at,omitempty"`
	CreatedAt     time.Time  `json:"created_at"`
	UpdatedAt     time.Time  `json:"updated_at"`
}

// BookingMessage is a single chat message between the customer and the
// technician assigned to a booking. sender_role tells the UI which side to
// render it on without needing an extra join.
type BookingMessage struct {
	ID         string    `json:"id"`
	BookingID  string    `json:"booking_id"`
	SenderID   string    `json:"sender_id"`
	SenderRole string    `json:"sender_role"` // "customer" | "technician"
	Content    string    `json:"content"`
	CreatedAt  time.Time `json:"created_at"`
}

// --- Detailed / joined shapes used by the customer + technician "my bookings" screens ---
//
// A customer viewing their own bookings needs to see WHO the assigned technician is
// (name, phone, rating, experience). A technician viewing their assigned jobs needs to
// see WHO the customer is (name, phone) and where the job is (address). BookingDetail
// carries both, joined in a single query — Technician is nil until one is assigned;
// Customer is always present.

type BookingCustomerInfo struct {
	ID    string `json:"id"`
	Name  string `json:"name"`
	Phone string `json:"phone"`
}

type BookingTechnicianInfo struct {
	ID              string  `json:"id"`
	Name            string  `json:"name"`
	Phone           string  `json:"phone"`
	CategoryName    string  `json:"category_name"`
	ExperienceYears int     `json:"experience_years"`
	RatingAvg       float64 `json:"rating_avg"`
	RatingCount     int     `json:"rating_count"`
	IsVerified      bool    `json:"is_verified"`
}

type BookingAddressInfo struct {
	Label   string `json:"label"`
	Line1   string `json:"line1"`
	Line2   string `json:"line2,omitempty"`
	City    string `json:"city"`
	State   string `json:"state"`
	Pincode string `json:"pincode"`
}

// BookingDetail embeds Booking so all its JSON fields (id, customer_id, technician_id,
// status, problem_description, ...) stay at the top level, with the joined info added
// alongside.
type BookingDetail struct {
	Booking
	CategoryName string                 `json:"category_name"`
	Address      *BookingAddressInfo    `json:"address,omitempty"`
	Customer     *BookingCustomerInfo   `json:"customer,omitempty"`
	Technician   *BookingTechnicianInfo `json:"technician,omitempty"`
}

type BookingStatusHistory struct {
	ID        string    `json:"id"`
	BookingID string    `json:"booking_id"`
	Status    string    `json:"status"`
	Note      string    `json:"note,omitempty"`
	CreatedAt time.Time `json:"created_at"`
}

// BookingEstimateItem is a single labour or parts line on an estimate —
// e.g. "Compressor replacement" (part, qty 1, unit_price 3500) or "Labour
// charge" (labour, qty 1, unit_price 500). Amount is quantity * unit_price,
// computed server-side so a tampered client can't submit a mismatched total.
type BookingEstimateItem struct {
	ID         string  `json:"id"`
	EstimateID string  `json:"estimate_id"`
	ItemType   string  `json:"item_type"` // "labour" | "part"
	Name       string  `json:"name"`
	Quantity   float64 `json:"quantity"`
	UnitPrice  float64 `json:"unit_price"`
	Amount     float64 `json:"amount"`
}

// BookingEstimate is what a technician submits after physically inspecting
// the job on-site — a breakdown of expected labour + parts cost — which the
// customer must approve before the technician proceeds (and, eventually,
// before Complete() can be called to raise the final invoice). Re-submitting
// after a decline creates a new BookingEstimate row rather than mutating the
// old one, so the full negotiation history is preserved.
type BookingEstimate struct {
	ID           string                `json:"id"`
	BookingID    string                `json:"booking_id"`
	TechnicianID string                `json:"technician_id"`
	Status       string                `json:"status"` // "pending" | "approved" | "declined"
	LabourAmount float64               `json:"labour_amount"`
	PartsAmount  float64               `json:"parts_amount"`
	TotalAmount  float64               `json:"total_amount"`
	Note         *string               `json:"note,omitempty"`          // technician's note explaining the estimate
	CustomerNote *string               `json:"customer_note,omitempty"` // customer's reason, set on decline
	Items        []BookingEstimateItem `json:"items,omitempty"`
	CreatedAt    time.Time             `json:"created_at"`
	DecidedAt    *time.Time            `json:"decided_at,omitempty"`
}

// BookingJobPhoto is a single "before" or "after" proof photo a technician
// attaches to a job — distinct from Booking.Images, which is the customer's
// own upload of the problem at booking time. Multiple photos per type are
// allowed (e.g. several angles), so these accumulate rather than overwrite.
type BookingJobPhoto struct {
	ID           string    `json:"id"`
	BookingID    string    `json:"booking_id"`
	TechnicianID string    `json:"technician_id"`
	PhotoType    string    `json:"photo_type"` // "before" | "after"
	ImageURL     string    `json:"image_url"`
	Caption      *string   `json:"caption,omitempty"`
	CreatedAt    time.Time `json:"created_at"`
}

// ServiceHistoryPayment is a slimmed-down view of a booking's payment — just enough
// to show what was paid and whether a repeat-customer discount applied — for the
// technician's per-customer Service History screen.
type ServiceHistoryPayment struct {
	Amount                float64  `json:"amount"`
	Status                string   `json:"status"`
	IsRepeatCustomer      bool     `json:"is_repeat_customer"`
	RepeatDiscountPercent *float64 `json:"repeat_discount_percent,omitempty"`
	RepeatDiscountAmount  *float64 `json:"repeat_discount_amount,omitempty"`
}

// ServiceHistoryEntry is one past booking between a specific customer and
// technician, with its payment/pricing-tier info attached (nil if never paid) —
// powers GET /technicians/:id/customers/:customerId/history.
type ServiceHistoryEntry struct {
	BookingDetail
	Payment *ServiceHistoryPayment `json:"payment,omitempty"`
}