package service

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"time"

	razorpay "github.com/razorpay/razorpay-go"

	"homefix-backend/internal/models"
	"homefix-backend/internal/repository"
)

// RazorpayService replaces the old raw upi://pay-intent flow (see the now-unused
// UpiService, kept only for the admin panel's Refund action) with a real payment
// gateway: an order is created server-side via the Razorpay API, the app opens
// Razorpay's Checkout SDK with that order_id, and once the customer pays, the app
// hands back Checkout's own response (razorpay_payment_id + razorpay_signature) —
// which this service independently re-verifies with an HMAC-SHA256 signature
// check using the account's key secret before ever marking a payment paid. This
// is the standard, gateway-verified alternative to trusting a bare "the UPI app
// said SUCCESS" client report.
type RazorpayService struct {
	client            *razorpay.Client
	keyID             string
	keySecret         string
	commissionPct     float64
	gstPct            float64
	repeatDiscountPct float64
	platformFee       float64
	visitFee          float64
	paymentRepo       *repository.PaymentRepository
	bookingRepo       *repository.BookingRepository
	technicianRepo    *repository.TechnicianRepository
	walletRepo        *repository.WalletRepository
	fcm               *FirebaseService
}

func NewRazorpayService(
	keyID, keySecret string,
	commissionPct float64,
	gstPct float64,
	repeatDiscountPct float64,
	platformFee float64,
	visitFee float64,
	paymentRepo *repository.PaymentRepository,
	bookingRepo *repository.BookingRepository,
	technicianRepo *repository.TechnicianRepository,
	walletRepo *repository.WalletRepository,
	fcm *FirebaseService,
) *RazorpayService {
	return &RazorpayService{
		client:            razorpay.NewClient(keyID, keySecret),
		keyID:             keyID,
		keySecret:         keySecret,
		commissionPct:     commissionPct,
		gstPct:            gstPct,
		repeatDiscountPct: repeatDiscountPct,
		platformFee:       platformFee,
		visitFee:          visitFee,
		paymentRepo:       paymentRepo,
		bookingRepo:       bookingRepo,
		technicianRepo:    technicianRepo,
		walletRepo:        walletRepo,
		fcm:               fcm,
	}
}

// RazorpayOrder is what the app needs to open Razorpay's Checkout SDK — the
// order_id ties Checkout's payment back to our own payment row, and key_id lets
// the app initialize Checkout without hardcoding it (still safe to expose
// client-side — it's the *public* key, never the secret).
type RazorpayOrder struct {
	Payment     *models.Payment `json:"payment"`
	OrderID     string          `json:"razorpay_order_id"`
	KeyID       string          `json:"razorpay_key_id"`
	AmountPaise int64           `json:"amount_paise"`
	Currency    string          `json:"currency"`
}

// CreateOrder validates the amount against the booking's invoiced final_price (if
// set), applies the repeat-customer discount + GST exactly like the old UPI flow
// did, creates a real order via the Razorpay API, and records a "created" payment
// row tagged with that order's ID.
func (s *RazorpayService) CreateOrder(ctx context.Context, bookingID, userID string, baseAmountRupees float64) (*RazorpayOrder, error) {
	booking, err := s.bookingRepo.GetByID(ctx, bookingID)
	if err != nil {
		return nil, err
	}
	if booking == nil {
		return nil, errors.New("booking not found")
	}
	if booking.FinalPrice != nil {
		const epsilon = 0.01
		diff := baseAmountRupees - *booking.FinalPrice
		if diff < -epsilon || diff > epsilon {
			return nil, fmt.Errorf("amount does not match invoiced amount of %.2f", *booking.FinalPrice)
		}
	}

	// Repeat-customer discount — disabled per product decision (see
	// invoice_screen.dart, which dropped the "Repeat customer discount" line
	// from what customers see). Since hiding a discount from the invoice
	// while still silently applying it would mean the displayed total no
	// longer matches what was actually calculated, the discount itself is
	// switched off here too rather than just hidden — pricing must match
	// what's shown. IsRepeatCustomer/RepeatDiscount* fields are kept on the
	// Payment model (and left unset below) purely so old rows/API consumers
	// that still read them don't break; no new discount is ever applied.
	var isRepeat bool
	var repeatDiscountPercent *float64
	var repeatDiscountAmount *float64
	effectiveBase := baseAmountRupees

	ref, err := generateTransactionRef()
	if err != nil {
		return nil, fmt.Errorf("razorpay: failed to generate transaction ref: %w", err)
	}

	// --- Fee line items (see config.PlatformFeeAmount / VisitFeeAmount) -------
	// A warranty-claim booking is a free re-fix: no platform fee, no visit fee.
	platformFee := s.platformFee
	visitCharge := s.visitFee
	if booking.IsWarrantyClaim {
		platformFee = 0
		visitCharge = 0
	} else {
		// The visit charge is billed once per booking. Skip it if it's already
		// been charged on an earlier invoice for this booking, or if the
		// customer paid a separate pre-visit fee for it.
		if already, aErr := s.bookingRepo.IsVisitFeeCharged(ctx, bookingID); aErr != nil {
			return nil, aErr
		} else if already {
			visitCharge = 0
		} else if vf, vErr := s.paymentRepo.GetByBookingIDAndType(ctx, bookingID, models.PaymentTypeVisitFee); vErr == nil && vf != nil && vf.Status == models.PaymentPaid {
			visitCharge = 0
		}
	}

	// GST is charged on the whole taxable subtotal: service amount (post
	// repeat-customer discount) + platform fee + visit charge.
	subtotal := effectiveBase + platformFee + visitCharge
	gstAmount := subtotal * s.gstPct / 100
	totalAmount := subtotal + gstAmount

	var visitFeeCredit *float64 // legacy field — unused now that visit fee is an explicit line

	amountPaise := int64(totalAmount*100 + 0.5) // Razorpay wants amount in the smallest currency unit (paise)

	orderData := map[string]interface{}{
		"amount":   amountPaise,
		"currency": "INR",
		"receipt":  ref,
		"notes": map[string]interface{}{
			"booking_id": bookingID,
			"user_id":    userID,
		},
	}
	orderResp, err := s.client.Order.Create(orderData, nil)
	if err != nil {
		return nil, fmt.Errorf("razorpay: failed to create order: %w", err)
	}
	orderID, _ := orderResp["id"].(string)
	if orderID == "" {
		return nil, errors.New("razorpay: order creation did not return an order id")
	}

	p := &models.Payment{
		BookingID:              bookingID,
		UserID:                 userID,
		TransactionRef:         ref,
		Amount:                 totalAmount,
		BaseAmount:             &effectiveBase,
		GstAmount:              &gstAmount,
		GstPercent:             &s.gstPct,
		PlatformFeeAmount:      &platformFee,
		VisitChargeAmount:      &visitCharge,
		Currency:               "INR",
		IsRepeatCustomer:       isRepeat,
		RepeatDiscountPercent:  repeatDiscountPercent,
		RepeatDiscountAmount:   repeatDiscountAmount,
		RazorpayOrderID:        &orderID,
		PaymentType:            models.PaymentTypeService,
		VisitFeeCredit:         visitFeeCredit,
	}
	created, err := s.paymentRepo.Create(ctx, p)
	if err != nil {
		return nil, err
	}

	return &RazorpayOrder{
		Payment:     created,
		OrderID:     orderID,
		KeyID:       s.keyID,
		AmountPaise: amountPaise,
		Currency:    "INR",
	}, nil
}

// ErrPaymentNotVerified is declared in upi_service.go (same package) and reused
// here — both flows report the same failure mode to callers.

// verifySignature re-derives Razorpay's signature exactly the way their docs
// specify: HMAC-SHA256 of "order_id|payment_id" using the account's key secret,
// hex-encoded, compared against what Checkout returned. This is the standard
// server-side check (same one Razorpay's own PHP/Node examples use directly,
// since the razorpay-go SDK doesn't expose a signature-verification helper) —
// what actually proves the payment response wasn't spoofed by a compromised or
// modified client. Never trust razorpay_payment_id alone.
func (s *RazorpayService) verifySignature(orderID, paymentID, signature string) bool {
	mac := hmac.New(sha256.New, []byte(s.keySecret))
	mac.Write([]byte(orderID + "|" + paymentID))
	expected := hex.EncodeToString(mac.Sum(nil))
	return hmac.Equal([]byte(expected), []byte(signature))
}

// VerifyAndCapture is the only place a payment (and therefore its booking) can
// become "paid". It independently re-derives and checks the Razorpay signature
// server-side (see verifySignature) rather than trusting the app's report of
// success — the same integrity guarantee a webhook would give, applied
// synchronously to the client's own callback.
func (s *RazorpayService) VerifyAndCapture(ctx context.Context, razorpayOrderID, razorpayPaymentID, razorpaySignature, method string) (*models.Payment, error) {
	if razorpayOrderID == "" || razorpayPaymentID == "" || razorpaySignature == "" {
		return nil, errors.New("razorpay: order id, payment id and signature are all required")
	}
	if !s.verifySignature(razorpayOrderID, razorpayPaymentID, razorpaySignature) {
		return nil, ErrPaymentNotVerified
	}

	p, err := s.paymentRepo.GetByRazorpayOrderID(ctx, razorpayOrderID)
	if err != nil {
		return nil, err
	}
	if p == nil {
		return nil, fmt.Errorf("razorpay: payment not found for order %s", razorpayOrderID)
	}
	if p.Status != models.PaymentCreated {
		// Already resolved (paid/failed/refunded) — idempotent no-op, never re-credit.
		return p, nil
	}

	booking, err := s.bookingRepo.GetByID(ctx, p.BookingID)
	if err != nil {
		return nil, err
	}
	if booking == nil {
		return nil, errors.New("razorpay: booking not found for this payment")
	}

	// Visit-fee payments are a much simpler capture: no commission split, no
	// technician wallet credit yet (that happens off the final invoice) —
	// just mark it paid and flip the booking's gate so the technician can be
	// sent "on the way".
	if p.PaymentType == models.PaymentTypeVisitFee {
		if method == "" {
			method = "razorpay"
		}
		invoiceNumber := fmt.Sprintf("VF-%s-%s", time.Now().Format("200601"), p.ID[:8])
		if err := s.paymentRepo.MarkVerifiedPaidRazorpay(
			ctx, razorpayOrderID, razorpayPaymentID, razorpaySignature, method, invoiceNumber,
			0, 0, 0, 0,
		); err != nil {
			return nil, err
		}
		if err := s.bookingRepo.SetVisitFeeStatus(ctx, booking.ID, models.VisitFeePaid); err != nil {
			return nil, err
		}
		if s.fcm != nil {
			_ = s.fcm.SendToUser(ctx, booking.CustomerID, "Payment successful",
				"Your visit fee payment was received successfully.",
				map[string]string{"booking_id": booking.ID, "type": "payment_success"})
		}
		return s.paymentRepo.GetByRazorpayOrderID(ctx, razorpayOrderID)
	}

	// Commission and the technician's earning are based on the service amount
	// (post repeat-customer discount) only — never on GST or the platform/visit
	// fees, which are platform revenue the technician has no claim to.
	serviceBase := p.Amount
	if p.BaseAmount != nil {
		serviceBase = *p.BaseAmount
	}
	platformCommission := serviceBase * s.commissionPct / 100
	technicianEarning := serviceBase - platformCommission

	// CGST/SGST split — India intra-state GST is always divided 50/50 between
	// the two. p.GstAmount was already computed at CreateOrder time (post
	// repeat-customer discount, pre-total) — just split it, don't recompute.
	var cgstAmount, sgstAmount float64
	if p.GstAmount != nil {
		cgstAmount = *p.GstAmount / 2
		sgstAmount = *p.GstAmount - cgstAmount // avoids a rounding-off-by-a-paisa mismatch vs GstAmount
	}

	if method == "" {
		method = "razorpay"
	}
	invoiceNumber := fmt.Sprintf("INV-%s-%s", time.Now().Format("200601"), p.ID[:8])

	if err := s.paymentRepo.MarkVerifiedPaidRazorpay(
		ctx, razorpayOrderID, razorpayPaymentID, razorpaySignature, method, invoiceNumber,
		cgstAmount, sgstAmount, platformCommission, technicianEarning,
	); err != nil {
		return nil, err
	}
	if err := s.bookingRepo.SetPaymentStatus(ctx, booking.ID, "paid"); err != nil {
		return nil, err
	}
	// Remember that this booking's one-time visit charge has now been collected,
	// so a return visit on the same booking isn't billed for it again.
	if p.VisitChargeAmount != nil && *p.VisitChargeAmount > 0 {
		if err := s.bookingRepo.SetVisitFeeCharged(ctx, booking.ID); err != nil {
			return nil, err
		}
	}

	// Credit the assigned technician's wallet with their net earning (amount
	// minus platform commission). If no technician is assigned yet, the payment
	// still succeeds — settlement can be reconciled manually.
	var techUserID string
	if booking.TechnicianID != nil {
		tech, err := s.technicianRepo.GetByID(ctx, *booking.TechnicianID)
		if err == nil && tech != nil {
			techUserID = tech.UserID
			_, _ = s.walletRepo.Credit(ctx, tech.UserID, technicianEarning, "booking_earning", &p.ID)
		}
	}

	if s.fcm != nil {
		_ = s.fcm.SendToUser(ctx, booking.CustomerID, "Payment successful",
			fmt.Sprintf("Your payment of \u20B9%.2f was received. Invoice %s is ready.", p.Amount, invoiceNumber),
			map[string]string{"booking_id": booking.ID, "type": "payment_success"})
		if techUserID != "" {
			_ = s.fcm.SendToUser(ctx, techUserID, "Payment received",
				fmt.Sprintf("Customer paid \u20B9%.2f for booking %s. Your earning: \u20B9%.2f.", p.Amount, booking.ID, technicianEarning),
				map[string]string{"booking_id": booking.ID, "type": "payment_success"})
		}
	}

	return s.paymentRepo.GetByRazorpayOrderID(ctx, razorpayOrderID)
}

// MarkFailed lets the app tell us Checkout was dismissed/cancelled/failed (e.g.
// the customer backed out of the payment sheet) so the payment record — and any
// retry UI — reflects that accurately.
func (s *RazorpayService) MarkFailed(ctx context.Context, razorpayOrderID string) error {
	p, err := s.paymentRepo.GetByRazorpayOrderID(ctx, razorpayOrderID)
	if err != nil {
		return err
	}
	if p == nil {
		return fmt.Errorf("razorpay: payment not found for order %s", razorpayOrderID)
	}
	return s.paymentRepo.MarkFailed(ctx, p.TransactionRef, strings.ToUpper("failed"), "")
}

func (s *RazorpayService) GetByID(ctx context.Context, id string) (*models.Payment, error) {
	return s.paymentRepo.GetByID(ctx, id)
}

func (s *RazorpayService) ListByUser(ctx context.Context, userID string) ([]models.Payment, error) {
	return s.paymentRepo.ListByUser(ctx, userID)
}

// ListByTechnician powers the technician side of the Payment History tab —
// see PaymentRepository.ListByTechnician for why this can't just reuse
// ListByUser (payments are keyed to the paying customer, not the technician).
func (s *RazorpayService) ListByTechnician(ctx context.Context, technicianID string) ([]models.Payment, error) {
	return s.paymentRepo.ListByTechnician(ctx, technicianID)
}

// HistoryForRequester is the single entry point GET /payments/history uses.
// A customer's own payments are keyed by user_id directly (ListByUser), but
// a technician viewing "their" payment history means "payments for jobs I
// worked", which lives on the booking, not the payment row — so for a
// technician we first resolve their technician_id from the logged-in user_id
// and go through ListByTechnician instead. Without this split, a technician
// calling this endpoint always got back an empty list (their user_id never
// matches payments.user_id, which belongs to the customer who paid) —
// that's why the Payment History tab and Total Earned looked empty even
// with completed, invoiced jobs.
func (s *RazorpayService) HistoryForRequester(ctx context.Context, userID, role string) ([]models.Payment, error) {
	if role != "technician" {
		return s.paymentRepo.ListByUser(ctx, userID)
	}
	tech, err := s.technicianRepo.GetByUserID(ctx, userID)
	if err != nil {
		return nil, err
	}
	if tech == nil {
		// No technician profile yet (e.g. KYC not submitted) — nothing to show.
		return []models.Payment{}, nil
	}
	return s.paymentRepo.ListByTechnician(ctx, tech.ID)
}

// GetInvoiceByBooking resolves the booking's most recent payment and returns
// its invoice — used by the technician side, which only has a booking ID on
// hand. Delegates to GetInvoice for the actual authorization + invoice build
// so the two entry points can never drift out of sync on who's allowed to see what.
func (s *RazorpayService) GetInvoiceByBooking(ctx context.Context, bookingID, requestingUserID string) (*models.InvoiceDetail, error) {
	p, err := s.paymentRepo.GetByBookingID(ctx, bookingID)
	if err != nil {
		return nil, err
	}
	if p == nil {
		return nil, errors.New("no payment found for this booking")
	}
	return s.GetInvoice(ctx, p.ID, requestingUserID)
}

// GetInvoice returns the full invoice for a payment — only once it's actually
// paid (a 'created' or 'failed' payment has no real invoice, just a would-be
// one, which would be misleading to hand back as if it were final).
func (s *RazorpayService) GetInvoice(ctx context.Context, paymentID, requestingUserID string) (*models.InvoiceDetail, error) {
	p, err := s.paymentRepo.GetByID(ctx, paymentID)
	if err != nil {
		return nil, err
	}
	if p == nil {
		return nil, errors.New("payment not found")
	}
	if p.UserID != requestingUserID {
		// Not the paying customer — but the technician who serviced this
		// booking should also be able to see the invoice once paid (so they
		// have proof of what the customer was actually charged/paid).
		authorized := false
		booking, bErr := s.bookingRepo.GetByID(ctx, p.BookingID)
		if bErr == nil && booking != nil && booking.TechnicianID != nil {
			tech, tErr := s.technicianRepo.GetByID(ctx, *booking.TechnicianID)
			if tErr == nil && tech != nil && tech.UserID == requestingUserID {
				authorized = true
			}
		}
		if !authorized {
			return nil, errors.New("you are not authorized to view this invoice")
		}
	}
	if p.Status != models.PaymentPaid && p.Status != models.PaymentRefunded {
		return nil, errors.New("invoice is only available once payment is complete")
	}
	inv, err := s.paymentRepo.GetInvoiceDetail(ctx, paymentID)
	if err != nil {
		return nil, err
	}
	if inv == nil {
		return nil, errors.New("invoice not found")
	}
	return inv, nil
}

// RefundVisitFee reverses a paid ₹99 visit-fee payment when a booking is
// cancelled after the customer already paid it — issues a real Razorpay
// refund (falling back to a wallet credit if that call fails) and moves the
// booking's visit_fee_status to "refunded". Called automatically from
// BookingService.Cancel; never touches booking.payment_status (that's the
// separate final-invoice flow).
func (s *RazorpayService) RefundVisitFee(ctx context.Context, bookingID string) error {
	p, err := s.paymentRepo.GetByBookingIDAndType(ctx, bookingID, models.PaymentTypeVisitFee)
	if err != nil {
		return err
	}
	if p == nil || p.Status != models.PaymentPaid {
		return nil // nothing paid, nothing to refund
	}

	if p.RazorpayPaymentID != nil && *p.RazorpayPaymentID != "" {
		amountPaise := int(p.Amount*100 + 0.5)
		if _, err := s.client.Payment.Refund(*p.RazorpayPaymentID, amountPaise, nil, nil); err != nil {
			fmt.Printf("[razorpay] visit-fee refund API call failed for payment %s (%s): %v\n", p.ID, *p.RazorpayPaymentID, err)
		}
	}

	if err := s.paymentRepo.Refund(ctx, p.ID, time.Now()); err != nil {
		return err
	}
	if err := s.bookingRepo.SetVisitFeeStatus(ctx, bookingID, models.VisitFeeRefunded); err != nil {
		return err
	}
	_, _ = s.walletRepo.Credit(ctx, p.UserID, p.Amount, "visit_fee_refund", &p.ID)
	return nil
}

// Refund reverses a verified payment: the booking's payment_status moves to
// "refunded", the technician's earning credit is clawed back, and the customer is
// credited the full amount to their in-app wallet. If the payment actually went
// through Razorpay (razorpay_payment_id set), a real refund is also issued via the
// Razorpay API so the money genuinely goes back to the customer's original payment
// method — not just an in-app credit. Falls back to wallet-only reversal (same as
// the old UPI flow) for any legacy payment that predates Razorpay.
func (s *RazorpayService) Refund(ctx context.Context, paymentID string) (*models.Payment, error) {
	p, err := s.paymentRepo.GetByID(ctx, paymentID)
	if err != nil {
		return nil, err
	}
	if p == nil {
		return nil, errors.New("payment not found")
	}
	if p.Status != models.PaymentPaid {
		return nil, errors.New("only a paid payment can be refunded")
	}

	if p.RazorpayPaymentID != nil && *p.RazorpayPaymentID != "" {
		amountPaise := int(p.Amount*100 + 0.5)
		if _, err := s.client.Payment.Refund(*p.RazorpayPaymentID, amountPaise, nil, nil); err != nil {
			// Log-and-continue: still reverse it on our side (booking/wallet) so the
			// customer isn't left in limbo just because the gateway call hiccuped —
			// an ops admin can reconcile the actual Razorpay-side refund manually.
			fmt.Printf("[razorpay] refund API call failed for payment %s (%s): %v\n", paymentID, *p.RazorpayPaymentID, err)
		}
	}

	if err := s.paymentRepo.Refund(ctx, paymentID, time.Now()); err != nil {
		return nil, err
	}
	if err := s.bookingRepo.SetPaymentStatus(ctx, p.BookingID, "refunded"); err != nil {
		return nil, err
	}

	if p.TechnicianEarning != nil {
		booking, err := s.bookingRepo.GetByID(ctx, p.BookingID)
		if err == nil && booking != nil && booking.TechnicianID != nil {
			tech, err := s.technicianRepo.GetByID(ctx, *booking.TechnicianID)
			if err == nil && tech != nil {
				_, _ = s.walletRepo.Debit(ctx, tech.UserID, *p.TechnicianEarning, "booking_refund_clawback", &p.ID)
			}
		}
	}
	_, _ = s.walletRepo.Credit(ctx, p.UserID, p.Amount, "booking_refund", &p.ID)

	return s.paymentRepo.GetByID(ctx, paymentID)
}